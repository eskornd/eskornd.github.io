//# sourceURL=webuiqt_ueci_common.js

console.log('webuiqt_ueci_common.js loaded');

class Editor
{
	constructor ()
	{
		this._storages = {'shared' : new Storage('shared') };
	}

	async appName()
	{
		try {
			let ret = await CPPCall('GetAppName');
			return ret;
		} catch (err) {
			return Promise.reject(err);
		}
	}

	async versionString()
	{
		try {
			let verStr = await CPPCall('GetVersionString');
			return verStr;
		} catch (err) {
			return Promise.reject(err);
		}
	}

	async version()
	{
		try {
			let version = await CPPCall('GetVersion');
			return version;
		} catch (err) {
			return Promise.reject(err);
		}
	}

	async appInfo()
	{
		try {
			let appInfo = await CPPCall('GetAppInfo');
			return appInfo;
		} catch (err) {
			return Promise.reject(err);
		}
	}

	async documents()
	{
		try {
			let docs = await CPPCall('GetDocuments');
		} catch (err) {
			return Promise.reject(err);
		}
		return CPPCall('GetDocuments');
	}

	async currentDocument() 
	{
		try {
			let doc = await CPPCall('GetCurrentDocument');
			buildDoc(doc);
			return doc;
		} catch (err) {
			return Promise.reject(err);
		}
	}

	async hello ()
	{
		alert('HELLO!');
	}

	async onDocumentChanged ()
	{
		// TODO: please connect me;
		console.warn('TODO: onDocumentChange() not overridden');
	}

	async onDocumentPageBoxesChanged ()
	{
		// TODO: please connect me;
		console.warn('TODO: onDocumentPageBoxesChange() not overridden');
	}
	
	async onDocumentPageNumberChanged ()
	{
		// TODO: please connect me;
		console.warn('TODO: onDocumentPageNumberChanged() not overridden');
	}
	
	async onDocumentStructuralDesignFileChanged ()
	{
		// TODO: please connect me;
		console.warn('TODO: onDocumentStructuralDesignFileChanged() not overridden');
	}

	async onAnnotationCreated(annotation)
	{
		console.log('Deprecated: please override onAnnotationCreated2()');
	}

	async onAnnotationCreated2(annotation, pageNumber)
	{
		// TODO: please connect me;
		console.warn('TODO: onAnnotationCreated2() not overriden');
	}

	async onAnnotationSelected(annotationID)
	{
		// TODO: please connect me;
		console.warn('TODO: onAnnotationSelected() not overriden');
	}

	async storage ()
	{
		const storageName = 'shared';
		return this._storages[storageName];
	}

	async showModal(modalParams)
	{
		try {
			let modalResult = await CPPCall('ShowModal', modalParams);
			return modalResult;
		} catch (err) {
			return Promise.reject(err);
		}
	}

	async openInBrowser(url)
	{
		try {
			let result = await CPPCall('OpenInBrowser', url);
			return result;
		} catch (err) {
			return Promise.reject(err);
		}
	}

	async writeFileBinary(data, defaultFileName)
	{
		try {
			let filePath = await CPPCall('GetSaveFileName', { defaultFileName: defaultFileName });
			if (!filePath) {
				return false;
			}

			let write_func = writeFileBinaryImpl()
			let result = await write_func(filePath, data);
			if (result) {
				CPPCall('DownloadEnd', { completed: true });
			}
			else {
				CPPCall('DownloadEnd', { completed: false });
			}

			return result;
		} catch (err) {
			return Promise.reject(err);
		}
	}

	async currentWindow()
	{
		let win = {
			isModal: async ()=>{
				return await CPPCall('IsModal');
			}
			, resize : async (size)=>{
				return await CPPCall('ResizeWindow', size);
			}
			, close : async () => { 
				return await CPPCall('CloseWindow');
			}

			, endModal : async (params) => {
				alert('TODO: UECI Window.endModal() called: ' + JSON.stringify(params) );
			}
		}
		return win;
	}

	async activateAnnotationTool(activateParams)
	{
		try {
			await CPPCall('ActivateAnnotationTool', activateParams);
		} catch (err) {
			return Promise.reject(err);
		}
	}

	async keychain (domain)
	{
		return new Keychain(domain);
	}

	async postMessage( message )
	{
		try {
			await CPPCall('PostMessage', message);
		} catch (err) {
			return Promise.reject(err);
		}
	}
}


// Async saving the document
class DocumentSaver
{
	constructor()
	{
		this._promiseId = 99;
		this._promises = {};
	}

	// Return promise of saving document
	async saveDocument(docID, silent)
	{
		++this._promiseId;
		const promiseId = this._promiseId;
		let promise = new Promise( (resolve, reject) => {
			this._promises[promiseId] = { resolve, reject} ;
		});

		try {
			await CPPCall('RequestSaveDocument', {promiseId: promiseId, docID : docID, silent : silent});
		} catch (err) {
			console.error(err);
		}
		return promise;
	}

	// Return promise of saved temp document
	async saveDocumentAsTemp(docID, clusterNodeIDURI)
	{
		++this._promiseId;
		const promiseId = this._promiseId;
		let promise = new Promise( (resolve, reject) => {
			this._promises[promiseId] = { resolve, reject} ;
		});

		try {
			let params = {promiseId: promiseId, docID : docID };
			if ( undefined != clusterNodeIDURI )
			{
				params.clusterNodeIDURI = clusterNodeIDURI;
			}
			await CPPCall('RequestSaveTemporaryDocument', params );
		} catch (err) {
			console.error(err);
		}
		return promise;
	}

	resolveSaveDocument(promiseId)
	{
		// Resolve in next event cycle, avoid returning too fast
		setTimeout( ()=> {
			this._promises[promiseId].resolve(true);
			delete this._promises[promiseId];
		}, 100);
	}

	rejectSaveDocument(promiseId, errorCode, errorMessage)
	{
		let error = 'Save document rejected';
		if ( errorCode != undefined && errorMessage != undefined)
		{
			error = {
				errorCode : errorCode
				, errorMessage : errorMessage
			}
		}

		// Reject in next event cycle, avoid returning too fast
		setTimeout( ()=> {
			this._promises[promiseId].reject(error);
			delete this._promises[promiseId];
		}, 100);
	}

	resolveSaveTemporaryDocument(promiseId, filePath)
	{
		// Resolve in next event cycle, avoid returning too fast
		setTimeout( ()=> {
			this._promises[promiseId].resolve(filePath);
			delete this._promises[promiseId];
		}, 100);
	}

	rejectSaveTemporaryDocument(promiseId, errorCode, errorMessage)
	{
		this.rejectSaveDocument(promiseId, errorCode, errorMessage);
	}

}

window.__esko_docsaver__ = new DocumentSaver();

function ClusterNodeIDToURI(clusterNodeID)
{
	let containsIllegalChars = (clusterNodeID) => {
		let format = /[ ;//?:@&=+$,\/]/;
		let found1 = format.test(clusterNodeID.cluster);
		let found2 = format.test(clusterNodeID.nodeID);
		return found1 || found2;

	};
	if ( containsIllegalChars(clusterNodeID))
	{
		let err = {errorCode:-1, errorMessage:'Illegal characters found in cluster or nodeID'};
		throw err;
	}
	let uri = 'eskocloud://' + clusterNodeID.cluster + '/' + clusterNodeID.nodeID;
	return uri;
}

function URIToClusterNodeID(uri)
{ 
	let obj = { 
		cluster : ''
		, nodeID : ''
	};
	const kProtocol = 'eskocloud://';
	try {
		const url = new URL(uri);
		if (uri.startsWith(kProtocol))
		{
			let body = uri.substr(kProtocol.length);
			const arr = body.split("/");
			if ( arr.length >=2 )
			{
				obj.cluster = arr[0];
				obj.nodeID = arr[1];
			}
		}
	} catch (err) {}
	return obj;
}

function makeFunction_SaveDocument(docID)
{
	return async (params) => 
	{
		let silent = false;
		if ( undefined != params && undefined != params.silent)
		{
			silent = params.silent;
		}
		try {
			await window.__esko_docsaver__.saveDocument(docID, silent);
			return Promise.resolve(true);
		} catch (err) {
			return Promise.reject(err);
		}
	}
}
		
function readFileBinaryImpl()
{
	return async (filePath, progressCallback) =>
	{
		let fileHandle = await CPPCall('OpenFile', { filePath : filePath, mode : "read" });
		console.log('fileHandle is ' + fileHandle);

		let fileLength = await CPPCall('FileLength', { fileHandle : fileHandle});
		console.log('fileLength is ' + fileLength);
		let buf = new ArrayBuffer(fileLength);
		const kBufSize = 256*1024;
		let totalBytes = 0;

		let u8Arr = new Uint8Array(buf);
		for (;;)
		{
			let base64 = await CPPCall('ReadFile', { fileHandle : fileHandle, bytes : kBufSize});
			const localArr = Uint8Array.from(atob(base64), (c) => c.charCodeAt(0));

			u8Arr.set(localArr, totalBytes);
			totalBytes += localArr.length;
			if ( undefined != progressCallback )
			{
				progressCallback(totalBytes, fileLength);
			}
			if (localArr.length == 0 )
			{
				console.warn('ReadFile: 0 bytes read.');
				break;
			}
			if (totalBytes == fileLength)
			{
				console.log(' Received ' + totalBytes + ' == fileLength: ' + fileLength);
				break;
			} else if ( totalBytes > fileLength ) {
				console.warn(' Received ' + totalBytes + ' which is greater than fileLength: ' + fileLength);
			}
		}
		await CPPCall('CloseFile', {fileHandle : fileHandle});
		return u8Arr;
	}
}

function makeFunction_ReadFileBinary(docID)
{
	return async (params, progressCallback) => {
		try{
			// save a temp copy file first
			const saveToTemp = true;
			let filePath = '';
			if ( saveToTemp )
			{
				let clusterNodeIDURI = undefined;
				if ( undefined != params && undefined != params.clusterNodeID)
				{
					try {
						clusterNodeIDURI = ClusterNodeIDToURI(params.clusterNodeID);
					} catch (err) {
						return Promise.reject(err);
					}
				}
				filePath = await window.__esko_docsaver__.saveDocumentAsTemp(docID, clusterNodeIDURI);
				console.log('Temp filePath is: ' + filePath);
			} else {
				filePath = await CPPCall('GetDocumentPath', {docID : docID});
			}

			let read_func = readFileBinaryImpl();
			let u8Arr = await read_func(filePath, progressCallback);
			return u8Arr;
		} catch (err) {
			return Promise.reject(err);
		}
	};
}

function writeFileBinaryImpl()
{
	return async (filePath, data) =>
	{
		let fileHandle = '';
		try {
			fileHandle = await CPPCall('OpenFile', { filePath: filePath, mode: "write" });
			console.log('fileHandle is ' + fileHandle);
		} catch (err) {
			console.warn('cannot get filehandle');
			return false;
		}

		let fileLength = data.length;
		console.log('fileLength is ' + fileLength);

		const kBufSize = 256 * 1024;
		let totalBytes = 0;
		let result = true;
		for (;;)
		{
			const localArr = data.subarray(totalBytes, totalBytes + kBufSize);
			let base64 = btoa(localArr.reduce((data, byte) => data + String.fromCharCode(byte), ''));
			let bytesWritten = await CPPCall('WriteFile', { fileHandle: fileHandle, data: base64 });
			totalBytes += bytesWritten;

			if (bytesWritten == 0)
			{
				console.warn('WriteFile: 0 bytes written.');
				result = false;
				break;
			}
			if (totalBytes == fileLength)
			{
				result = true;
				break;
			}
			else if (totalBytes > fileLength)
			{
				console.warn('Wrote ' + totalBytes + ' which is greater than fileLength: ' + fileLength);
				result = false;
				break;
			}
		}
		await CPPCall('CloseFile', { fileHandle: fileHandle });
		return result;
	}
}

class Storage
{
	constructor (name)
	{
		// TODO: name must conforms to a file name
		this._name = name;
		console.log('Storage constructed:' + this._name);
	}

	async setValue(key, value)
	{
		console.log('setValue called ' + key + ' = ' + value);
		try {
			let ret = CPPCall('SetValue', { 
				storageName: this._name, 
				key: key, 
				value: value});
			console.log('setValue ret: ' + JSON.stringify(ret));
			return ret.value;
		} catch (err) {
			console.error(err);
		}
		return null;
	}

	async getValue(key)
	{
		console.log('getValue called ' + key);
		try {
			let ret = await CPPCall('GetValue', { 
				storageName: this._name, 
				key: key});
			console.log('getValue ret: ' + JSON.stringify(ret));
			return ret.value;
		} catch (err) {
			console.error(err);
		}
		return null;
	}
}

class Keychain
{
	constructor (inDomain)
	{
		this.domain = 'undefined' === typeof inDomain ? 'eu.esko.cloud' : inDomain;
		console.log('Keychain constructed for ' + this.domain);
	}

	async setUserToken(token)
	{
		console.log('setUserToken called: ' + token);
		try {
			let ret = CPPCall('SetUserToken', { userToken: token, domain : this.domain } );
			console.log('setUserToken ret: ' + JSON.stringify(ret));
			return ret;
		} catch (err) {
			console.error(err);
		}
		return null;
	}

	async getUserToken()
	{
		console.log('getUserToken called!');
		try {
			let ret = await CPPCall('GetUserToken', { domain : this.domain} );
			console.log('getUserToken ret: ' + JSON.stringify(ret));
			return ret;
		} catch (err) {
			console.error(err);
		}
		return null;
	}

	async deleteUserToken()
	{
		console.log('deleteUserToken called!');
		try {
			let ret = CPPCall('DeleteUserToken', {domain : this.domain} );
			console.log('deleteUserToken ret: ' + JSON.stringify(ret));
			return ret;
		} catch (err) {
			console.error(err);
		}
		return null;
	}
}

function makeFunction_GetDocumentPath(docID)
{
	return ()=>{
		return CPPCall('GetDocumentPath', {docID: docID});
	};
}

function makeFunction_GetDocumentTitle(docID)
{
	return ()=>{
		return CPPCall('GetDocumentTitle', {docID: docID});
	};
}

function makeFunction_GetDocumentPageBoxes(docID)
{
	return () => {
		return CPPCall('GetDocumentPageBoxes', {docID: docID});
	};
}

function makeFunction_GetDocumentSelectedPageIndex(docID)
{
	return () => {
		return CPPCall('GetDocumentSelectedPageIndex', {docID: docID});
	};
}

function makeFunction_GetDocumentIsDirty(docID)
{
	return () => {
		return CPPCall('GetDocumentIsDirty', {docID: docID});
	};
}

function makeFunction_SetDocumentAnnotations(docID)
{
	return (annotations) => {
		let params = {
			docID : docID
			, annotations : annotations
		};
		return CPPCall('SetDocumentAnnotations', params);
	}
}

function makeFunction_GetDocumentAnnotations(docID)
{
	return (annotations) => {
		let params = {
			docID : docID
		};
		return CPPCall('GetDocumentAnnotations', params);
	}
}

function makeFunction_SetDocumentClusterNodeID(docID)
{
	let encodeToURI = (clusterNodeID) => {
		let uri = 'eskocloud://' + clusterNodeID.cluster + '/' + clusterNodeID.nodeID;
		return uri;
	};

	let containsIllegalChars = (clusterNodeID) => {
		let format = /[ ;//?:@&=+$,\/]/;
		let found1 = format.test(clusterNodeID.cluster);
		let found2 = format.test(clusterNodeID.nodeID);
		return found1 || found2;

	};
	return (clusterNodeID) => {
		let uri = '';
		try { 
			uri = ClusterNodeIDToURI(clusterNodeID);
		} catch (err)
		{
			return Promise.reject(err);
		}
		let params = {
			docID : docID
			, clusterNodeIDURI : uri
		};
		return CPPCall('SetDocumentClusterNodeID', params);
	}
}

function makeFunction_GetDocumentClusterNodeID(docID)
{
	return async (annotations) => {
		let params = {
			docID : docID
		};
		const uri = await CPPCall('GetDocumentClusterNodeID', params);
		const clusterNodeID = URIToClusterNodeID(uri);
		return clusterNodeID;
	}
}

function makeFunction_SetDocumentNodeID(docID)
{
	return (nodeID) => {
		let params = {
			docID : docID
			, nodeID : nodeID
		};
		return CPPCall('SetDocumentNodeID', params);
	}
}

function makeFunction_GetDocumentNodeID(docID)
{
	return (annotations) => {
		let params = {
			docID : docID
		};
		return CPPCall('GetDocumentNodeID', params);
	}
}

function makeFunction_GetDocumentStructuralDesignFiles(docID)
{
	return (files) => {
		let params = {
			docID : docID
		};
		return CPPCall('GetDocumentStructuralDesignFiles', params);
	}
}
		
function makeFunction_ReadStructuralDesignFileBinary(docID)
{
	return async (filePath, progressCallback) => {
		try {
			let allFilePaths = await CPPCall('GetDocumentStructuralDesignFiles', { docID : docID });
			if (!Array.isArray(allFilePaths) || !allFilePaths.includes(filePath))
			{
				throw "Invalid structual design file '" + filePath + "'";
			}

			let read_func = readFileBinaryImpl();
			let u8Arr = await read_func(filePath, progressCallback);
			return u8Arr;
		} catch (err) {
			return Promise.reject(err);
		}
	};
}

function makeFunction_HasPDFAnnotation(docID)
{
	return () => {
		return CPPCall('HasPDFAnnotation', {docID: docID});
	};
}

function buildDoc(doc)
{
	doc.title = makeFunction_GetDocumentTitle(doc.id);
	doc.filePath = makeFunction_GetDocumentPath(doc.id);
	doc.setAnnotations = makeFunction_SetDocumentAnnotations(doc.id);
	doc.getAnnotations = makeFunction_GetDocumentAnnotations(doc.id);
	doc.pagesInfo = makeFunction_GetDocumentPageBoxes(doc.id);
	doc.pageNumber = makeFunction_GetDocumentSelectedPageIndex(doc.id);
	doc.isDirty = makeFunction_GetDocumentIsDirty();
	doc.readFileBinary = makeFunction_ReadFileBinary(doc.id);
	doc.saveDocument = makeFunction_SaveDocument(doc.id);
	doc.setNodeID = makeFunction_SetDocumentNodeID(doc.id);
	doc.getNodeID = makeFunction_GetDocumentNodeID(doc.id);
	doc.setClusterNodeID = makeFunction_SetDocumentClusterNodeID(doc.id);
	doc.getClusterNodeID = makeFunction_GetDocumentClusterNodeID(doc.id);
	doc.getPlacedSDFilePaths = makeFunction_GetDocumentStructuralDesignFiles(doc.id);
	doc.readPlacedSDFileBinary = makeFunction_ReadStructuralDesignFileBinary(doc.id);
	doc.hasPDFAnnotation = makeFunction_HasPDFAnnotation(doc.id);
}

