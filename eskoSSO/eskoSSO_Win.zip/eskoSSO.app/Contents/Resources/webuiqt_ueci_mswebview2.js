//# sourceURL=webuiqt_ueci_mswebview2.js
console.log('webuiqt_ueci_mswebview2.js loaded');

// Define postMessage object as literal to delay evaluation
let POSTER_LITERAL = 'window.chrome.webview';

