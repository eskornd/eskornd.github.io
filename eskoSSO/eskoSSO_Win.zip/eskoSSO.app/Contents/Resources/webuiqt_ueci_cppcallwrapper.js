//# sourceURL=webuiqt_ueci_cppcallwrapper.js

console.log('webuiqt_ueci_cppcallwrapper.js loaded');

// will be called by webview
window.__esko_bootloader__ = 
{
	initEditor : async () => {
		console.log('initEditor called');
		buildEditor();
		publishEditor();
		return '';
	}
};

class AppError
{
	constructor( inErrorCode, inErrorMessage) 
	{
		this.errorCode = inErrorCode;
		this.errorMessage = inErrorMessage;
	}
}


// JS -> CPP call wrapper
// Webkit doesn't support return value, we need to implement this via promises
// see http://igomobile.de/2017/03/06/wkwebview-return-a-value-from-native-code-to-javascript/
class CPPCallWrapper
{
	constructor(inPosterLiteral)
	{
		this._promises = {};
		this._posterLiteral = inPosterLiteral;
	}

	// see https://stackoverflow.com/questions/105034/how-to-create-a-guid-uuid
	generateUUID()
	{
		var d = new Date().getTime();//Timestamp
		var d2 = ((typeof performance !== 'undefined') && performance.now && (performance.now()*1000)) || 0;//Time in microseconds since page-load or 0 if unsupported
		return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
			var r = Math.random() * 16;//random number between 0 and 16
			if(d > 0){//Use timestamp until depleted
				r = (d + r)%16 | 0;
				d = Math.floor(d/16);
			} else {//Use microseconds since page-load if supported
				r = (d2 + r)%16 | 0;
				d2 = Math.floor(d2/16);
			}
			return (c === 'x' ? r : (r & 0x3 | 0x8)).toString(16);
		});
	}

	// For CPP returning values
	resolvePromise(promiseID, callName, data, errorCode)
	{
		//console.log('CPPCallWrapper resolvePromise called: ' + promiseID + ', ' + callName + ', ' + data + ', errorCode:' + errorCode);
		if (errorCode)
		{
			// data should be error message string now
			const err = new AppError(errorCode, data);
			this._promises[promiseID].reject(err);
		} else{
			this._promises[promiseID].resolve(data);
		}
		// remove reference to stored promise
		delete this._promises[promiseID];
	};
	/**
	 * Call from js to cpp
	 * @param callName, the CPP call function name
	 * @param params, the javascript object.
	 */
	async cppCall(callName, params)
	{
		let promise =  new Promise((resolve, reject) => 
		{
			let promiseID = this.generateUUID();
			this._promises[promiseID] = {resolve, reject};
			const obj = {
				promiseID : promiseID
				, callName : callName
				, params : params
				, __application : 'ueci_call_wrapper'
			};
			try {
				let poster = eval(this._posterLiteral);
				console.assert( undefined != poster);
				poster.postMessage( JSON.stringify(obj) );
			}catch (err)
			{
				console.error(err);
			}
		});
		return promise;
	}
}

// webViewPoster is defined in _webkit.js or _webview2.js
window.__esko_callwrapper__ = new CPPCallWrapper(POSTER_LITERAL);

// publish this function for common.js to use
async function CPPCall(callName, params){
	return window.__esko_callwrapper__.cppCall(callName, params);
}

// TODO: move to common.js
let myEditor;
function buildEditor()
{
	try
	{
		myEditor = new Editor();
	} catch (err) {
		console.error('Exception caught: ' + err.message);
	}
}

// TODO: move to common.js
function publishEditor()
{
	const kEventEditorReady = 'com.esko.editorconnector.ready'; 
	const globalPropertyName = '__esko_editor__';
	window[globalPropertyName] = myEditor;

	// The client side should listen to the event and retrieve editor by window[event.detail.globalPropertyName]
	let detail = { globalPropertyName : globalPropertyName };
	document.dispatchEvent(new CustomEvent(kEventEditorReady, { detail : detail}));

	console.log('window.__esko_editor__ published');
}

